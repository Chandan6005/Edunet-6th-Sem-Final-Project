from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from dashboard.utils import calculate_bmi, bmi_category

@login_required
def dashboard_view(request):
    profile = request.user.profile

    bmi = None
    category = "Update your profile to calculate BMI"

    if profile.weight and profile.height:
        bmi = calculate_bmi(profile.weight, profile.height)
        category = bmi_category(bmi)

    context = {
        'bmi': bmi,
        'category': category,
        'goal': profile.goal,
        'weight': profile.weight,
        'height': profile.height,
    }


    return render(request,'dashboard.html', context)