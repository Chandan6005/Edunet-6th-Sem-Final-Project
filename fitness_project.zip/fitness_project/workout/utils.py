def determine_level(bmi):
    if bmi is None:
        return 'beginner'
    elif bmi < 18.5:
        return 'beginner'
    elif bmi < 25:
        return 'intermediate'
    else:
        return 'advanced'