from django.apps import AppConfig


class HelpdeskConfig(AppConfig):
    name = 'helpdesk'
