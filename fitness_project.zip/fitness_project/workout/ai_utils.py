import os
from google import genai
from django.conf import settings
from anthropic import Anthropic
from openai import OpenAI

gemini_client = None
claude_client = None
openai_client = None

if settings.GEMINI_API_KEY:
    gemini_client = genai.Client(api_key=settings.GEMINI_API_KEY)

if settings.CLAUDE_API_KEY:
    claude_client = Anthropic(api_key=settings.CLAUDE_API_KEY)

if settings.OPENAI_API_KEY:
    openai_client = OpenAI(api_key=settings.OPENAI_API_KEY)

def generate_workout_plan(profile, level, goal):
    prompt = f"""
    You are a professional fitness trainer.print

    User details:
    - Age: {profile.age}
    - Height: {profile.height} m
    - Weight: {profile.weight} kg
    - BMI: {round(profile.weight / ((profile.height/100)**2), 2)}
    - Fitness level: {level}
    - Goal: {goal}

    Generate a 7-day workout plan.
    Include:
    - Day-wise exercises
    - Sets and reps
    - Rest days
    Keep it safe and realistic.
    """

    if gemini_client:
        try:
            response = gemini_client.models.generate_content(
                model="gemini-3-pro-preview",
                # model="gemini-2.0-flash",
                contents=prompt
            )
            return response.text
        except Exception as e:
            print("Gemini failed:",e)

    if claude_client:
        try:
            response = claude_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=800,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            return response.content[0].text
        except Exception as e:
            print("Claude failed:",  e)
    
    if openai_client:
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a professional fitness trainer."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=800
            )
            return response.choices[0].message.content
        except Exception as e:
            print("OpenAI ChatGPT failed:", e)
    
    else :
        return f"""
    AI service is temporarily unavailable.

    Sample Workout Plan ({level} - {goal}):

    Day 1: Full Body (Push-ups, Squats, Plank)
    Day 2: Cardio (Brisk walk / Cycling)
    Day 3: Upper Body
    Day 4: Rest
    Day 5: Lower Body
    Day 6: Core + Cardio
    Day 7: Rest
    
    This is a generic plan. Please try again later for AI-personalized guidance.
    """
    