from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Diet
# Create your views here.

@login_required
def diet_view(request):
    profile = request.user.profile
    goal = profile.goal

    meals = Diet.objects.filter(goal=goal)

    return render(request, 'diet.html', {
        'meals': meals,
        'goal':goal
    })