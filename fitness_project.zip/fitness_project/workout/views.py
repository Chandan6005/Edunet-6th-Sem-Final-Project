from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from workout.models import Workout
from workout.ml_utils import predict_workout_level
from dashboard.utils import calculate_bmi
from .ai_utils import generate_workout_plan
# Create your views here.

@login_required
def workout_view(request):
    profile = request.user.profile
    RAW_GOAL = profile.goal or 'maintain'

    GOAL_MAP = {
        'Weight loss': 'lose',
        'Weight gain': 'gain',
        'Maintain': 'maintain',
        'lose': 'lose',
        'gain': 'gain',
        'maintain': 'maintain',
    }

    goal = GOAL_MAP.get(RAW_GOAL, 'maintain')
    
    age = profile.age or 25
    height = profile.height or 1.7
    weight = profile.weight or 70

    bmi = None
    if profile.height and profile.weight:
        bmi = calculate_bmi(profile.height, profile.weight)
    else:
        bmi = 22
    
    level = predict_workout_level(age, height, weight, bmi, goal)
    cache_key = f"workout_{request.user.id}_{goal}_{level}"
    ai_workout_plan = cache.get(cache_key)
    
    if not ai_workout_plan:
        ai_workout_plan = generate_workout_plan(profile, level, goal)
        cache.set(cache_key, ai_workout_plan,  timeout=3600)

    return render(request, 'workout.html', {
        'level': level,
        'goal': goal,
        'ai_workout_plan': ai_workout_plan,
    })