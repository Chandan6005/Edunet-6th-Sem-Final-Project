from django.apps import AppConfig


class DietConfig(AppConfig):
    name = 'diet'
